# TODOS - Auth to HF (huggingface cli login) and OpenAI (openai.api_key)

This is a Python application that allows you to evaluate how well LLMs handle the order dependency problem, drawing heavily from the paper [Large Language Models Are not Robust Multiple Choice Selectors](https://openreview.net/pdf?id=shr9PXz7T0) by Zheng, et al. It is written to easily handle multiple models with limited extra work.

# Installation


# Authorization
## Data
To access the Huggingface dataset, use the Huggingface CLI to authenticate your account.

## OpenAI
To access the OpenAI API, set your OpenAI API key in your own `.env` file.

# Future Work
This project could be extended in many ways.