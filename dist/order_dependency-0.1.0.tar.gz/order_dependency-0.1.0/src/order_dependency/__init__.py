from .main import run_full_analysis
